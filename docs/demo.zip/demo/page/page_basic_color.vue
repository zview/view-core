<template>
    <div class="page-color">

        <Panel>{{message}}</Panel>

    </div>
</template>

<script>
    export default {
        data () {
            return {
                message: '颜色',
            }
        },
        methods: {

        },
    }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
