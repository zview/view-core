<template>
    <div class="page-badge">

        <Row>
            <Col>
                <Badge text="12">文本</Badge>
            </Col>
            <Col>
                <Badge text="99<sup>+</sup>">文本</Badge>
            </Col>
        </Row>

    </div>
</template>

<script>
    export default {
        data () {
            return {
                message: '徽标',
            }
        },
        methods: {

        },
    }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
