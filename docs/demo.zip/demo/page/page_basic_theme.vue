<template>
    <div class="page-theme">

        <Panel>{{message}}</Panel>

    </div>
</template>

<script>
    export default {
        data () {
            return {
                message: '多主题',
            }
        },
        methods: {

        },
    }
</script>

<style lang="scss" rel="stylesheet/scss" scoped>

</style>
